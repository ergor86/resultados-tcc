#!/bin/bash


# Itera sobre cada arquivo CSV no diretório
for arquivo in *.csv
do
    # Lê cada linha do arquivo
    echo "$arquivo"
    while read linha
    do
        echo "$linha" | xargs | sed 's/ /|/g' | sed 's/|||/|/g' | sed 's/||/|/g' | sed 's/|/;/g' | sed 's/M//g' | sed  's/G//g' | sed 's/%//g'>> TRATADO-$arquivo
    done < "$arquivo"
done
